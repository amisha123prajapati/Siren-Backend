exports.heroData = {
    posterBig: "https://upload.wikimedia.org/wikipedia/en/thumb/b/b4/Doctor_Strange_in_the_Multiverse_of_Madness_logo.png/220px-Doctor_Strange_in_the_Multiverse_of_Madness_logo.png",
    posterTwo: [
        {
            imageUrl: "https://images.pexels.com/photos/669996/pexels-photo-669996.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260",
            id: "123456",
            title: "Learn the web and build one for yourself",
            category: "Technology",
            date: " / August 22 2021"
            
        },
        {
            imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHB4NUTn78zwdqlVRJjeJf8D2VMR4hdFrLFQ&usqp=CAU",
            id: "654321",
            title: "Read and Eat Healthy",
            category: "Food",
            date: " / August 23 2021"
        }
    ]
}

