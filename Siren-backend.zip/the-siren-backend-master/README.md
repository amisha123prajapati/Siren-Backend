# The Siren Backend

A diverse blog webapp for posting various articles like Technology, Fitness, Food, Bollywood, Hollywood etc.

# Link to Frontend:

https://github.com/zrajesh/the-siren-frontend
